// output.h -- Przemek Gardias (pmgardias)

#ifndef OUTPUT_H_
#define OUTPUT_H_

void printResults(FILE *out);
void freeNode(node *origin);

#endif /* OUTPUT_H_ */
