// input.h -- Przemek Gardias (pmgardias)

#ifndef INPUT_H_
#define INPUT_H_

void formatWord(char* word);
node* addNode(char *word, node *origin);

#endif /* INPUT_H_ */
