// main.h -- Eric Arthur (etarthur) & Przemek Gardias (pmgardias)

#ifndef MAIN_H_
#define MAIN_H_
#include "Organism.h"

bool onEdge(int x, int y);
bool canAttack(int x, int y);

#endif /* MAIN_H_ */
