// life.h -- Przemek Gardias (pmgardias)

#ifndef LIFE_H_
#define LIFE_H_

#include <stdio.h>

void PlayOne(int rows, int cols, int *A[], int *B[], int gens);
void printBoard(int rows, int cols, int *A[]);

#endif /* LIFE_H_ */
